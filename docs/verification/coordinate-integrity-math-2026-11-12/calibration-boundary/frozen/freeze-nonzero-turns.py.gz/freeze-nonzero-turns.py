#!/usr/bin/env python3
import json,hashlib,itertools
from fractions import Fraction as F
from pathlib import Path
R=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
encode=lambda v:(json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode()
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def extreme(points):
 pts=sorted(set(tuple(F(x) for x in p) for p in points));lines=[]
 for a,b in itertools.combinations(pts,2):
  values=[cross(a,b,c) for c in pts]
  if (all(v>=0 for v in values) or all(v<=0 for v in values)) and any(v!=0 for v in values):lines.append((a,b))
 vertices=[]
 for p in pts:
  directions=[(b[0]-a[0],b[1]-a[1]) for a,b in lines if cross(a,b,p)==0]
  if any(u[0]*v[1]-u[1]*v[0]!=0 for u,v in itertools.combinations(directions,2)):vertices.append([float(x) for x in p])
 return vertices
cases=[];expected=[]
for height in [1e-10,1e-12,1e-13,0.,-1e-12]:
 points=[[.1,.1],[.9,.1],[.9,.9],[.5,.9+height],[.1,.9]]
 for mode in ['identity','swap','reflect']:
  transform=lambda p:p if mode=='identity' else [p[1],p[0]] if mode=='swap' else [1-p[0],p[1]]
  image=[transform(p) for p in points]
  for order,indices in [('ordered',list(range(5))),('permuted',[3,1,4,0,2])]:
   refs=[{'role':'fit','image':{'x':image[i][0],'y':image[i][1]},'ground':{'x':100*image[i][0],'y':100*image[i][1]}} for i in indices]+[{'role':'check','image':{'x':.5,'y':.5},'ground':{'x':50.,'y':50.}}]
   id=f'nonzero-turn/{height}/{mode}/{order}'
   cases.append({'id':id,'references':refs});expected.append({'id':id,'fitAccepted':True,'extremeVertices':extreme(image),'maximumErrorMetres':1e-7})
inputs={'schema':'dvr-calibration-turn-inputs-v1','cases':cases};values={'schema':'dvr-calibration-turn-expected-v1','cases':expected}
for name,value in [('turn-inputs.json',inputs),('turn-expected.json',values)]:
 p=R/name;assert not p.exists();p.write_bytes(encode(value))
receipt={'schema':'dvr-calibration-turn-freeze-v1','inputsSha256':sha((R/'turn-inputs.json').read_bytes()),'expectedSha256':sha((R/'turn-expected.json').read_bytes()),'generatorSha256':sha(Path(__file__).read_bytes()),'cases':len(cases),'exclusions':0,'frozenBeforeCandidate':True,'oracle':'Extreme vertices are intersections of nonparallel exact supporting lines, using Fraction(binary64). All positive nonzero turns are retained; truly collinear/inside points are not extreme.'}
(R/'turn-freeze-receipt.json').write_bytes(encode(receipt));print(json.dumps(receipt,indent=2))
