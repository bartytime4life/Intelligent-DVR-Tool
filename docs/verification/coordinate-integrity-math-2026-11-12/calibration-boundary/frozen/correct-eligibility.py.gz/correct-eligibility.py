#!/usr/bin/env python3
"""Pre-candidate v2 correction: independently classify existing distinct-check refusals; retain every input."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib,shutil
R=Path(__file__).resolve().parent;pre=R/'preparation-v1';pre.mkdir(exist_ok=False)
for name in ['freeze-corpus.py','inputs.json','expected.json','freeze-receipt.json','check-hull.py','observe.mjs']:
 shutil.copyfile(R/name,pre/name)
shutil.copytree(R/'pr117-baseline',pre/'pr117-baseline')
encode=lambda v:(json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode()
sha=lambda b:hashlib.sha256(b).hexdigest()
inputs=json.loads((R/'inputs.json').read_bytes());expected=json.loads((R/'expected.json').read_bytes());refused=[]
for case,e in zip(inputs['fits'],expected['fits']):
 fits=[p for p in case['references'] if p['role']=='fit'];checks=[p for p in case['references'] if p['role']=='check'];bad=[]
 for c in checks:
  for f in fits:
   dsquare=sum((F(c['ground'][axis])-F(f['ground'][axis]))**2 for axis in ['x','y'])
   if dsquare<F(.01)**2:bad.append({'groundDistanceSquared':str(dsquare),'minimumDistance':'.01m'})
 if bad:
  e['fitAccepted']=False;e['expectedRefusal']='Independent check markers';e['refusalEvidence']=bad;refused.append(case['id'])
inputs['schema']='dvr-calibration-hull-inputs-v2';inputs['eligibility']='200 finite helper scenes retained. 126 fitted-transform inputs retained: 105 valid fits and 21 expected refusals from the pre-existing 0.01m independent-marker separation rule, independently classified before any candidate execution. No point exclusions, snapping or tolerance-based orientation.'
expected['schema']='dvr-calibration-hull-expected-v2'
(R/'inputs.json').write_bytes(encode(inputs));(R/'expected.json').write_bytes(encode(expected))
assert len(refused)==21
receipt={'schema':'dvr-calibration-hull-freeze-v2','inputsSha256':sha((R/'inputs.json').read_bytes()),'expectedSha256':sha((R/'expected.json').read_bytes()),'originalGeneratorSha256':sha((pre/'freeze-corpus.py').read_bytes()),'eligibilityCorrectionSha256':sha(Path(__file__).read_bytes()),'geometryCases':len(inputs['geometry']),'geometryQueries':sum(len(c['queries']) for c in inputs['geometry']),'fitCases':len(inputs['fits']),'validFitCases':len(inputs['fits'])-len(refused),'expectedReferenceRefusals':len(refused),'validFitQueries':sum(len(c['queries']) for c,e in zip(inputs['fits'],expected['fits']) if e['fitAccepted']),'allOriginalCoordinatesUnchanged':True,'exclusions':0,'frozenBeforeCandidate':True,'correction':'21 originally presumed-valid fixtures have holdout ground separation about 0.007071m from a fit marker, below the existing 0.01m rule. They now require refusal; all original input cases/coordinates are retained. Original expectations/checker and failed baseline are preserved under preparation-v1.'}
assert all(a['vertices']==b['vertices'] and a['queries']==b['queries'] for a,b in zip(inputs['geometry'],json.loads((pre/'inputs.json').read_bytes())['geometry']))
assert inputs['fits']==json.loads((pre/'inputs.json').read_bytes())['fits']
(R/'freeze-receipt.json').write_bytes(encode(receipt));print(json.dumps(receipt,indent=2))
