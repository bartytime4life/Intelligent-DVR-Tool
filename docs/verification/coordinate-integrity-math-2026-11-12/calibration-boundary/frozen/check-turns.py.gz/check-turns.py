#!/usr/bin/env python3
import argparse,hashlib,json,subprocess,shutil,math
from pathlib import Path
HERE=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest()
p=argparse.ArgumentParser();p.add_argument('--module',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--require-pass',action='store_true');args=p.parse_args();out=args.out.resolve();out.mkdir(parents=True,exist_ok=False)
f=json.loads((HERE/'turn-freeze-receipt.json').read_bytes());inputs=json.loads((HERE/'turn-inputs.json').read_bytes());expected=json.loads((HERE/'turn-expected.json').read_bytes())
assert sha((HERE/'turn-inputs.json').read_bytes())==f['inputsSha256'];assert sha((HERE/'turn-expected.json').read_bytes())==f['expectedSha256']
source=args.module.resolve();snapshot=out/source.name;shutil.copyfile(source,snapshot)
runner="import{readFileSync}from'node:fs';import{pathToFileURL}from'node:url';const{fitPlanarCalibration}=await import(pathToFileURL(process.argv[1]));const a=JSON.parse(readFileSync(process.argv[2],'utf8'));console.log(JSON.stringify(a.cases.map(c=>{try{return{id:c.id,value:fitPlanarCalibration(c.references)}}catch(e){return{id:c.id,error:String(e.message)}}})));"
raw=subprocess.check_output(['node','--input-type=module','-e',runner,str(snapshot),str(HERE/'turn-inputs.json')]);(out/'observed.json').write_bytes(raw);observed=json.loads(raw);checks=0;failures=[]
for c,e,a in zip(inputs['cases'],expected['cases'],observed):
 checks+=1
 if 'value' not in a:failures.append({'id':c['id'],'group':'fit-accepted','actual':a});continue
 v=a['value'];checks+=4
 if sorted(v['fittingHull'])!=sorted(e['extremeVertices']):failures.append({'id':c['id'],'group':'exact-extreme-vertices','actual':v['fittingHull'],'expected':e['extremeVertices']})
 if v['fit']['max']>e['maximumErrorMetres'] or v['holdout']['max']>e['maximumErrorMetres']:failures.append({'id':c['id'],'group':'reference-error','actual':[v['fit'],v['holdout']]})
 if not v['checkInsideHull']:failures.append({'id':c['id'],'group':'check-inside'})
 if v['verified'] is not False:failures.append({'id':c['id'],'group':'no-self-verification'})
receipt={'schema':'dvr-calibration-turn-result-v1','sourceSha256':sha(source.read_bytes()),'checkerSha256':sha(Path(__file__).read_bytes()),'runnerSha256':sha(runner.encode()),'inputsSha256':f['inputsSha256'],'expectedSha256':f['expectedSha256'],'observedSha256':sha(raw),'cases':len(inputs['cases']),'assertions':checks,'failedAssertions':len(failures),'failures':failures,'pass':not failures,'exclusions':0}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k!='failures'},indent=2));print(json.dumps({'firstFailures':failures[:2]},indent=2));raise SystemExit(1 if args.require_pass and failures else 0)
