import {readFileSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
const [modulePath,inputPath]=process.argv.slice(2);
const {insideReferenceHull,fitPlanarCalibration,calibratedGroundDistance}=await import(pathToFileURL(modulePath));
const inputs=JSON.parse(readFileSync(inputPath,'utf8'));
const safe=(fn)=>{try{return{value:fn()};}catch(error){return{error:String(error?.message||error)};}};
const geometry=inputs.geometry.map(c=>({id:c.id,queries:c.queries.map(q=>safe(()=>insideReferenceHull(q.point,c.vertices)))}));
const fits=inputs.fits.map(c=>{
 const result=safe(()=>fitPlanarCalibration(c.references));
 if(result.error)return{id:c.id,error:result.error};
 const calibration=result.value;
 return{id:c.id,calibration,queries:c.queries.map(q=>({inside:safe(()=>insideReferenceHull(q.point,calibration.fittingHull)),ruler:safe(()=>calibratedGroundDistance(calibration,c.from,q.point))}))};
});
console.log(JSON.stringify({geometry,fits}));
