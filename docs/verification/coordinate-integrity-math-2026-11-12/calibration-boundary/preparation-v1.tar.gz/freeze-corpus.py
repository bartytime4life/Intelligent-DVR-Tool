#!/usr/bin/env python3
"""Generate independent binary64 support-line membership expectations before candidate execution."""
import hashlib,json,math,itertools,random
from pathlib import Path
from fractions import Fraction as F
R=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def encode(v):return (json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode()
def qpt(p):return tuple(F(x) for x in p)
def orient(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def supports(vertices):
 points=sorted(set(map(qpt,vertices)));lines=[]
 for a,b in itertools.combinations(points,2):
  signs=[orient(a,b,c) for c in points]
  if all(s==0 for s in signs):continue
  if all(s>=0 for s in signs):lines.append((a,b,1))
  elif all(s<=0 for s in signs):lines.append((a,b,-1))
 return lines

def membership(point,lines):
 if not lines:return False,False
 signs=[orient(a,b,qpt(point))*direction for a,b,direction in lines]
 inside=all(s>=0 for s in signs)
 return inside,inside and any(s==0 for s in signs)

base=[('unit-square',[[0.,0.],[1.,0.],[1.,1.],[0.,1.]]),('dyadic-square',[[.125,.125],[.875,.125],[.875,.875],[.125,.875]]),('triangle',[[.1,.1],[.9,.2],[.4,.9]]),('clipped-corner',[[0.,0.],[1.,0.],[1.,.9999],[.9999,1.],[0.,1.]]),('short-edge',[[.1,.1],[.9,.1],[.9,.8999999],[.8999999,.9],[.1,.9]]),('near-collinear-spike',[[.1,.1],[.9,.1],[.9,.9],[.5,.900000000001],[.1,.9]]),('thin-positive',[[.1,.5],[.9,.5],[.9,.500000000001],[.1,.500000000001]]),('tiny-positive',[[.5,.5],[.50000001,.5],[.50000001,.50000001],[.5,.50000001]]),('collinear',[[.1,.1],[.3,.3],[.5,.5],[.9,.9]]),('repeated-point',[[.5,.5],[.5,.5],[.5,.5]])]
transforms=[('identity',[1,0,0,1,0,0]),('swap',[0,1,1,0,0,0]),('reflect-x',[-1,0,0,1,1,0]),('half',[.5,0,0,.5,.125,.125]),('dyadic-shear',[.5,.125,.125,.5,.125,.125])]
def transform(p,t):a,b,c,d,e,f=t;return[a*p[0]+b*p[1]+e,c*p[0]+d*p[1]+f]
geometry=[];expected_geo=[]
for name,points in base:
 queries=[{'label':'centroid','point':[sum(p[i] for p in points)/len(points) for i in range(2)]},{'label':'generic-inner','point':[.5,.5]},{'label':'generic-outer','point':[.99,.01]}]
 for i,p in enumerate(points):
  queries.append({'label':f'vertex-{i}','point':p})
  for axis in [0,1]:
   for direction in [-math.inf,math.inf]:
    pert=p.copy();pert[axis]=math.nextafter(pert[axis],direction);queries.append({'label':f'vertex-{i}-axis-{axis}-{direction}','point':pert})
  b=points[(i+1)%len(points)];mid=[(p[j]+b[j])/2 for j in [0,1]]
  queries.append({'label':f'edge-{i}-midpoint','point':mid})
  for axis in [0,1]:
   for direction in [-math.inf,math.inf]:
    pert=mid.copy();pert[axis]=math.nextafter(pert[axis],direction);queries.append({'label':f'edge-{i}-axis-{axis}-{direction}','point':pert})
 if name=='clipped-corner':queries += [{'label':'reported-outside','point':[.999954,.999954]},{'label':'near-corner-inside','point':[.99994,.99994]}]
 for tname,t in transforms:
  mapped=[transform(p,t) for p in points]
  # Perturbations happen after transform as well: transformed ULPs are genuinely distinct input floats.
  mapped_queries=[{'label':p['label'],'point':transform(p['point'],t)} for p in queries]
  for p in mapped:
   for axis in [0,1]:
    for direction in [-math.inf,math.inf]:
     pert=p.copy();pert[axis]=math.nextafter(pert[axis],direction);mapped_queries.append({'label':f'world-nextafter-{axis}-{direction}','point':pert})
  orders=[('ordered',mapped),('reversed',mapped[::-1]),('permuted',mapped[::2]+mapped[1::2]),('duplicated',mapped+[mapped[0],mapped[-1]])]
  for order,verts in orders:
   case={'id':f'{name}/{tname}/{order}','kind':'finite-helper-domain','vertices':verts,'queries':mapped_queries}
   lines=supports(verts)
   expected_geo.append({'id':case['id'],'queries':[{'inside':membership(p['point'],lines)[0],'boundary':membership(p['point'],lines)[1]} for p in mapped_queries]})
   geometry.append(case)

base_fit=[[0.,0.],[1.,0.],[1.,.9999],[.9999,1.],[0.,1.]]
images=transforms+[('reflect-y',[1,0,0,-1,0,1]),('three-quarter-shear',[.75,.125,.125,.75,.05,.05])]
ground_transforms=[('identity',[1,0,0,1,0,0]),('rotated-translated',[0,-2,2,0,100,-100])]
model=[.01,0,0,0,.01,0,-1,-1,2]
def mapping(p):x,y=p;return[.01*x/(2-x-y),.01*y/(2-x-y)]
def inverse(t,p):
 a,b,c,d,e,f=map(F,t);x,y=map(F,p);det=a*d-b*c
 return[(d*(x-e)-b*(y-f))/det,(-c*(x-e)+a*(y-f))/det]
def project_exact(p,t,g):
 x,y=inverse(t,p);k=F(.01);den=2-x-y;v=[k*x/den,k*y/den];a,b,c,d,e,f=map(F,g)
 return[a*v[0]+b*v[1]+e,c*v[0]+d*v[1]+f]
fits=[];expected_fit=[]
checks=[('inside',[.9,.9]),('outside',[.999954,.999954]),('short-edge-boundary',[.99995,.99995])]
query_base=[('inside',[.99994,.99994]),('reported-outside',[.999954,.999954]),('ordinary-interior',[.5,.5]),('short-edge-boundary',[.99995,.99995]),('vertex',[1.,.9999]),('corner-outside',[1.,1.]),('near-boundary-outside',[math.nextafter(.99995,math.inf),.99995])]
for tn,t in images:
 image_fit=[transform(p,t) for p in base_fit];lines=supports(image_fit)
 for gn,g in ground_transforms:
  def reference(p,role):
   image=transform(p,t);ground=transform(mapping(p),g);return{'role':role,'image':{'x':image[0],'y':image[1]},'ground':{'x':ground[0],'y':ground[1]}}
  for check_name,check in checks:
   for order,points in [('ordered',base_fit),('reversed',base_fit[::-1]),('permuted',base_fit[::2]+base_fit[1::2])]:
    refs=[reference(p,'fit') for p in points]+[reference(check,'check')]
    start=transform([.9,.9],t);queries=[{'label':name,'point':transform(p,t)} for name,p in query_base]
    case={'id':f'perspective/{tn}/{gn}/{check_name}/{order}','references':refs,'from':start,'queries':queries,'imageTransform':t,'groundTransform':g,'baseHomography':model,'toleranceMetres':1e-5,'maximumFitAndCheckErrorMetres':1e-6}
    exp_queries=[]
    for p in queries:
     inside,boundary=membership(p['point'],lines)
     if inside:
      a,b=project_exact(start,t,g),project_exact(p['point'],t,g);d2=sum((a[i]-b[i])**2 for i in range(2));distance=math.sqrt(float(d2))
     else:distance=None
     exp_queries.append({'inside':inside,'boundary':boundary,'rulerAvailable':inside,'metres':distance})
    check_inside=membership(transform(check,t),lines)[0]
    fits.append(case);expected_fit.append({'id':case['id'],'fitAccepted':True,'checkInsideHull':check_inside,'queries':exp_queries})
inputs={'schema':'dvr-calibration-hull-inputs-v1','geometry':geometry,'fits':fits,'eligibility':'All finite helper queries retained; valid fit fixtures fixed before candidate execution. No point exclusions, coordinate snapping or tolerance-based orientation.','oracle':'Exact Fraction(binary64) pairwise supporting-line halfplanes; no monotone-chain hull algorithm.'}
expected={'schema':'dvr-calibration-hull-expected-v1','geometry':expected_geo,'fits':expected_fit}
for name,value in [('inputs.json',inputs),('expected.json',expected)]:
 path=R/name
 assert not path.exists(),f'Frozen file already exists: {name}'
 path.write_bytes(encode(value))
receipt={'schema':'dvr-calibration-hull-freeze-v1','inputsSha256':sha((R/'inputs.json').read_bytes()),'expectedSha256':sha((R/'expected.json').read_bytes()),'generatorSha256':sha(Path(__file__).read_bytes()),'geometryCases':len(geometry),'geometryQueries':sum(len(c['queries']) for c in geometry),'fitCases':len(fits),'fitQueries':sum(len(c['queries']) for c in fits),'exclusions':0,'frozenBeforeCandidate':True}
(R/'freeze-receipt.json').write_bytes(encode(receipt));print(json.dumps(receipt,indent=2))
