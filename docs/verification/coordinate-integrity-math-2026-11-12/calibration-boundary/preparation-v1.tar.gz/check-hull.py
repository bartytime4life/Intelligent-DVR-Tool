#!/usr/bin/env python3
"""Strict source-bound check of immutable independent exact support-line expectations."""
import argparse,hashlib,json,math,re,shutil,subprocess
from pathlib import Path
HERE=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--repo',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--require-pass',action='store_true');args=p.parse_args()
repo=args.repo.resolve();out=args.out.resolve();out.mkdir(parents=True,exist_ok=False)
freeze=json.loads((HERE/'freeze-receipt.json').read_bytes())
for name,key in [('inputs.json','inputsSha256'),('expected.json','expectedSha256')]:
 assert sha((HERE/name).read_bytes())==freeze[key],name
 shutil.copyfile(HERE/name,out/name)
inputs=json.loads((out/'inputs.json').read_bytes());expected=json.loads((out/'expected.json').read_bytes());files={}
def snapshot(name):
 if name in files:return
 path=repo/name;raw=path.read_bytes();files[name]=sha(raw);dest=out/'snapshot'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
 text=raw.decode()
 for dependency in re.findall(r'''(?:from\s*|import\s*)['"]([^'"]+)['"]''',text):
  if not dependency.startswith('.'):raise ValueError('Review new nonrelative dependency: '+dependency)
  target=(Path(name).parent/dependency).as_posix()
  snapshot(target)
snapshot('src/facility-calibration.mjs')
runner=HERE/'observe.mjs';shutil.copyfile(runner,out/'observe.mjs')
raw=subprocess.check_output(['node',str(out/'observe.mjs'),str(out/'snapshot/src/facility-calibration.mjs'),str(out/'inputs.json')]);(out/'observed.json').write_bytes(raw);observed=json.loads(raw)
checks={};failures=[]
def check(group,ok,**detail):
 checks[group]=checks.get(group,0)+1
 if not ok:failures.append(dict(group=group,**detail))
check('geometry-case-count',len(observed['geometry'])==len(inputs['geometry']))
for case,truth,actual in zip(inputs['geometry'],expected['geometry'],observed['geometry']):
 check('geometry-binding',case['id']==truth['id']==actual['id'],id=case['id'])
 check('geometry-query-count',len(actual['queries'])==len(truth['queries']),id=case['id'])
 for query,e,a in zip(case['queries'],truth['queries'],actual['queries']):
  check('exact-hull-membership',a.get('value') is e['inside'],id=case['id'],label=query['label'],point=query['point'],expected=e['inside'],actual=a)
check('fit-case-count',len(observed['fits'])==len(inputs['fits']))
for case,truth,actual in zip(inputs['fits'],expected['fits'],observed['fits']):
 id=case['id'];check('fit-binding',id==truth['id']==actual['id'],id=id)
 check('fit-accepted','calibration' in actual,id=id,actual=actual.get('error'))
 if 'calibration' not in actual:continue
 c=actual['calibration']
 check('fit-errors',c['fit']['max']<=case['maximumFitAndCheckErrorMetres'],id=id,actual=c['fit'])
 check('check-errors',c['holdout']['max']<=case['maximumFitAndCheckErrorMetres'],id=id,actual=c['holdout'])
 check('withheld-check-membership',c['checkInsideHull'] is truth['checkInsideHull'],id=id,expected=truth['checkInsideHull'],actual=c['checkInsideHull'])
 check('no-self-verification',c['verified'] is False,id=id,actual=c['verified'])
 check('fit-query-count',len(actual['queries'])==len(truth['queries']),id=id)
 for query,e,a in zip(case['queries'],truth['queries'],actual['queries']):
  check('fitted-hull-membership',a['inside'].get('value') is e['inside'],id=id,label=query['label'],point=query['point'],expected=e['inside'],actual=a['inside'])
  r=a['ruler'].get('value');available=r is not None and 'error' not in a['ruler']
  check('ruler-availability',available is e['rulerAvailable'],id=id,label=query['label'],expected=e['rulerAvailable'],actual=a['ruler'])
  if e['rulerAvailable'] and available:
   check('ruler-distance',isinstance(r.get('metres'),(int,float)) and math.isfinite(r['metres']) and abs(r['metres']-e['metres'])<=case['toleranceMetres'],id=id,label=query['label'],expected=e['metres'],actual=r)
receipt={'schema':'dvr-calibration-hull-result-v1','sourceRevision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'sourceFiles':files,'checkerSha256':sha(Path(__file__).read_bytes()),'runnerSha256':sha(runner.read_bytes()),'inputsSha256':freeze['inputsSha256'],'expectedSha256':freeze['expectedSha256'],'freezeReceiptSha256':sha((HERE/'freeze-receipt.json').read_bytes()),'observedSha256':sha(raw),'geometryCases':len(inputs['geometry']),'geometryQueries':sum(len(c['queries']) for c in inputs['geometry']),'fitCases':len(inputs['fits']),'fitQueries':sum(len(c['queries']) for c in inputs['fits']),'checks':checks,'assertions':sum(checks.values()),'failedAssertions':len(failures),'failures':failures,'pass':not failures,'exclusions':0,'orientationContract':'Exact sign of binary64 coordinate determinant; closed convex hull. Original reference values and nextafter perturbations are retained without snapping or tolerance inflation.','fittingTolerance':'Fixed before candidate: 1e-6m maximum reference error, 1e-5m independent expected ruler difference. Boundary membership is exact, not relaxed by these fit tolerances.'}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='failures'},indent=2,sort_keys=True));print(json.dumps({'firstFailures':failures[:8]},indent=2));raise SystemExit(1 if args.require_pass and failures else 0)
