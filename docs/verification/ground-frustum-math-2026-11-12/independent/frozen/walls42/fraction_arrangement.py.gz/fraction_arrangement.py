#!/usr/bin/env python3
"""Exact independent Fraction arrangement oracle; generated polygons only.

All vertex and pairwise edge-intersection ordinates divide the plane into slabs.
Within a slab every crossing order is fixed. Each horizontal interval endpoint is
an affine function of y, so interval lengths are affine and midpoint integration
is EXACT. Fractions interpret each source IEEE-754 coordinate as an exact binary
rational. No polygon-clipping code or candidate geometry helper is imported.
"""
import argparse
from collections import Counter,defaultdict
from fractions import Fraction as F
import hashlib
import gzip
import json
import math
from pathlib import Path
import shutil
import subprocess
import sys

HERE=Path(__file__).resolve().parent
if hasattr(sys,'set_int_max_str_digits'):sys.set_int_max_str_digits(0)
KEYS=('area','coveredArea','overlapArea','uncoveredArea','coverage','overlap')
SOURCES=('facility-coverage.mjs','facility.mjs','facility-stairs.mjs','facility-doorways.mjs','facility-windows.mjs','facility-zones.mjs')
sha=lambda data:hashlib.sha256(data).hexdigest()
encode=lambda value:(json.dumps(value,sort_keys=True,separators=(',',':'))+'\n').encode()

def ring(raw):return [(F(p[0]),F(p[1])) for p in raw]
def edges(points):return list(zip(points,points[1:]+points[:1]))
def cross(a,b):return a[0]*b[1]-a[1]*b[0]
def sub(a,b):return a[0]-b[0],a[1]-b[1]
def ring_area(points):
    return abs(sum((cross(a,b) for a,b in edges(points)),F(0)))/2

def union(intervals):
    result=[]
    for a,b in sorted(intervals):
        if b<=a:continue
        if result and a<=result[-1][1]:result[-1]=(result[-1][0],max(b,result[-1][1]))
        else:result.append((a,b))
    return result

def difference(left,right):
    answer=[]
    for a,b in left:
        at=a
        for c,d in right:
            if d<=at:continue
            if c>=b:break
            if c>at:answer.append((at,min(c,b)))
            at=max(at,d)
            if at>=b:break
        if at<b:answer.append((at,b))
    return answer

def intersection(left,right):
    answer=[];i=j=0
    while i<len(left) and j<len(right):
        a,b=left[i];c,d=right[j]
        if max(a,c)<min(b,d):answer.append((max(a,c),min(b,d)))
        if b<d:i+=1
        else:j+=1
    return answer

def horizontal(points,y):
    crossings=[]
    for a,b in edges(points):
        if (a[1]>y)!=(b[1]>y):crossings.append(a[0]+(y-a[1])*(b[0]-a[0])/(b[1]-a[1]))
    crossings.sort()
    if len(crossings)%2:raise ValueError('Odd crossings in oracle ring')
    return union(list(zip(crossings[::2],crossings[1::2])))

def polygon_intervals(polygons,y):
    result=[]
    for polygon in polygons:
        if not polygon:continue
        body=horizontal(polygon[0],y)
        holes=union([item for hole in polygon[1:] for item in horizontal(hole,y)])
        result.extend(difference(body,holes))
    return union(result)

def arrangement(zone,fans,extra=()):
    # Geometry comparison covers the entire returned geometry's extent as well
    # as the zone, so a misplaced output part outside the zone is also measured.
    extent=zone+[point for points in extra for point in points]
    ys={p[1] for p in extent};low,high=min(ys),max(ys)
    xmin,xmax=min(p[0] for p in extent),max(p[0] for p in extent)
    active=[]
    for points in [zone]+[points for _,points in fans]+list(extra):
        ys.update(p[1] for p in points if low<p[1]<high)
        for a,b in edges(points):
            x0,x1=sorted((a[0],b[0]));y0,y1=sorted((a[1],b[1]))
            if y0==y1 or y1<=low or y0>=high or x1<xmin or x0>xmax:continue
            active.append((a,b,x0,x1,y0,y1))
    pairs=0
    for i,(a,b,x0,x1,y0,y1) in enumerate(active):
        ab=sub(b,a)
        for c,d,u0,u1,v0,v1 in active[i+1:]:
            if x1<u0 or u1<x0 or y1<v0 or v1<y0:continue
            pairs+=1
            cd=sub(d,c);den=cross(ab,cd)
            if not den:continue
            q=sub(c,a);t=cross(q,cd)/den;s=cross(q,ab)/den
            if 0<t<1 and 0<s<1:
                y=a[1]+t*ab[1]
                if low<y<high:ys.add(y)
    return sorted(ys),len(active),pairs

def sections(zone,fans,y):
    zone_i=horizontal(zone,y)
    cameras=defaultdict(list)
    for identity,points in fans:cameras[identity].extend(horizontal(points,y))
    events=[]
    for a,b in zone_i:events.extend([(a,'__zone__',1),(b,'__zone__',-1)])
    for identity,intervals in cameras.items():
        for a,b in union(intervals):events.extend([(a,identity,1),(b,identity,-1)])
    events.sort()
    counts=Counter();at=None;covered=[];overlapped=[];uncovered=[]
    for x,identity,delta in events:
        if at is not None and x>at and counts['__zone__']:
            n=sum(value>0 for key,value in counts.items() if key!='__zone__')
            (covered if n else uncovered).append((at,x))
            if n>1:overlapped.append((at,x))
        counts[identity]+=delta;at=x
    return union(zone_i),union(covered),union(overlapped),union(uncovered)

length=lambda intervals:sum((b-a for a,b in intervals),F(0))

def exact_stats(case,returned=None):
    zone=ring(case['footprint']);fans=[(str(f['id']),ring(f['ring'])) for f in case['fans']]
    output=[[[ (F(p[0]),F(p[1])) for p in points] for points in polygon] for polygon in returned] if returned is not None else None
    critical,count,pairs=arrangement(zone,fans,[points for polygon in output for points in polygon] if output else ())
    totals=[F(0)]*4;xor_area=F(0);witnesses=0
    for bottom,top in zip(critical,critical[1:]):
        middle=(bottom+top)/2
        found=sections(zone,fans,middle)
        for i,intervals in enumerate(found):totals[i]+=length(intervals)*(top-bottom)
        if output is not None:
            actual=polygon_intervals(output,middle);wanted=found[3]
            xor_area+=(length(difference(actual,wanted))+length(difference(wanted,actual)))*(top-bottom)
            witnesses+=len(actual)+len(wanted)
    area,covered,overlap,uncovered=totals
    assert area==ring_area(zone)
    assert covered+uncovered==area and 0<=overlap<=covered<=area
    result=dict(zip(KEYS,totals+[covered/area,overlap/area]))
    return result,{'slabs':len(critical)-1,'relevant_edges':count,'edge_pair_checks':pairs,'xorArea':xor_area,'interval_witnesses':witnesses}

def valid_multipolygon(value):
    return isinstance(value,list) and all(isinstance(poly,list) and len(poly)>0 and all(isinstance(points,list) and len(points)>=4 and all(isinstance(p,list) and len(p)==2 and all(isinstance(n,(int,float)) and not isinstance(n,bool) and math.isfinite(n) for n in p) for p in points) for points in poly) for poly in value)

def contains(points,p):
    return any(a<p[0]<b for a,b in horizontal(points,p[1]))

def on_boundary(points,p):
    return any(cross(sub(p,a),sub(b,a))==0 and min(a[0],b[0])<=p[0]<=max(a[0],b[0]) and min(a[1],b[1])<=p[1]<=max(a[1],b[1]) for a,b in edges(points))

