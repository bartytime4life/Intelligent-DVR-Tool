# Ground-frustum study — 2026-11-12

The existing footprint has a concrete projection defect on supported valid camera inputs. It applies centreline near/far distances to every horizontal ray, then treats horizontal sensor FOV as a fixed ground-azimuth wedge. A rectangular pinhole sensor does neither after tilt. The resulting drawn fans and `seesPoint` can both include ground outside the sensor and exclude ground inside it.

This is an offline generated geometry study. It changes no application files. No camera, recording, model, inference, server or browser was started. No physical calibration, optics, visibility, identity, recognition quality, hardware capacity or installed-state claim follows from it. Obstacles are empty in all reproduced cases, so these examples are independent of the separate wall approximation.

## Source and frozen evidence

Executed public source snapshot: `730df9a3e45d96bb9bf154e809bf8d03c10c4c64` (zone-area branch).

`src/facility.mjs` SHA256: `dc6d0a44a608c6c07df92ccff06b64b6ba082c6a574763589ba67c177ae53df6`.

This file is also byte-identical at local `main` and `63b06ba2aab3adcffc38f52310b55969fb538afe`. The branch's current `coverageMetrics` is used to quantify the zone/route UI consequences; its precise drawn-polygon integrator does not correct an inaccurate footprint model.

- `inputs.json`: 31 valid plans, 59 point queries; SHA256 `b90b54b25d18a14b9400445f101c755a3f2bc7b501d15489e284a54fb764bce3`.
- `check-frustum.py`: SHA256 `d061baa6dfcfeba7f31c4e9cec70087475d66227a55171e5957075382f7026a0`.
- `observe.mjs`: SHA256 `e5c460cae37f3bd069a96ed5595676e0d7be22ed4dee3a38a6562b5674c771a3`.
- `baseline-authoritative/receipt.json`: SHA256 `4a82f24779a7ceb637e256bb05273f5013a84c61aca1bf2de360b16a02238b7e`.
- Full source and already-installed public dependency files are copied beneath `baseline-authoritative/snapshot`; the receipt binds every copied file. Actual baseline functions execute from that snapshot.
- Full raw fan vertices, point classifications, zone/route results and rehearsal samples are in `baseline-authoritative/observed.json`.
- Projection coordinates, ideal areas and independent expected scalar results are in `baseline-authoritative/expected.json`.

Strict replay from the source checkout, writing a fresh output directory:

```sh
python3 /tmp/dvr-frustum-study-20261112/check-frustum.py --repo . --out /tmp/dvr-frustum-study-20261112/replay-new --require-pass
```

The current baseline intentionally exits **1**: 946 assertions, 116 retained source-versus-ideal mismatches. All 31 plans validate. All 715 inverse-projection checks, 31 independent horizontal-strip area integrations, 18 finite-trapezoid closed-form area checks and three disk/tangent analytic checks pass. The 116 source mismatches are 42 `seesPoint`, 44 drawn-fan point membership, 10 zone fractions, 10 route fractions and 10 rehearsal midpoint classifications. They are assertion counts across related fixtures/rotations, not 116 distinct defects or a field failure rate.

The two extra drawn-fan point mismatches are exactly on a true horizontal range circle. `seesPoint` includes those points while the 48-chord fan excludes them; retain this existing, separate circle-polygonization effect rather than calling it a sensor projection error.

Fixture preparation is retained transparently: initial rotated exactly-one-square-metre zones sometimes fell below the validator's one-square-metre minimum through floating arithmetic; those zones were enlarged before any candidate implementation. The initial rejected corpus is `inputs-initial-invalid.json`. Area-oracle preparation found two versions of tangent midpoint classification error (including a slightly negative rounded discriminant). `check-frustum-initial.py`, `check-frustum-before-strip-crosscheck.py` and exploratory outputs remain. The authoritative checker treats isolated tangent midpoints as outside an otherwise-outside segment, tests three disk closed forms, and independently confirms all 31 whole-footprint areas by horizontal-strip integration. `baseline-authoritative` is the authoritative run. No production candidate was executed or used to change a tolerance or expected answer.

## Derivation

Official primary basis: [OpenCV camera calibration/projection documentation](https://docs.opencv.org/4.13.0/d9/d0c/group__calib3d.html), especially its camera-frame perspective division and field-of-view/focal-length equations. The following ground footprint is derived from that model; OpenCV does not assert that this application's manually entered cameras are calibrated.

Use local east/north/up world axes. Bearing is clockwise from north, downward tilt is theta, mount height is z > 0, and horizontal/vertical FOV are H and V. Let

- F = (sin bearing, cos bearing, 0), horizontal forward;
- R = (cos bearing, -sin bearing, 0), image right;
- K = (0,0,1), world up;
- A = cos(theta) F - sin(theta) K, optical forward;
- B = -sin(theta) F - cos(theta) K, image down.

For a ground point relative to the mount, q = X R + Y F - z K. Dot products give camera coordinates

```text
camera-right  = X
camera-down   = W = z cos(theta) - Y sin(theta)
optical depth = D = Y cos(theta) + z sin(theta)
```

A centred distortion-free rectangular sensor sees the point exactly when

```text
D > 0
|X| <= a D, where a = tan(H/2)
|W| <= v D, where v = tan(V/2)
```

Preserve the current range interpretation separately as the horizontal disk

```text
X² + Y² <= range².
```

These are five affine halfplanes plus a disk; their intersection is convex before walls. There is no need for a polar-angle support restriction, a clamp at 89.9 degrees or an assumption that all visible ground is in the forward horizontal halfplane. Keeping the four sensor halfplanes and explicit positive depth avoids division by nearly zero depth.

The vertical sensor constraints simplify to forward-coordinate bounds

```text
Ymin = z cot(theta + V/2)                   (signed; may be negative)
Ymax = z cot(theta - V/2), if theta > V/2
Ymax = +infinity,             otherwise.
```

Together with `|X| <= a (Y cos(theta) + z sin(theta))` and the disk, these describe the same footprint. Use the affine constraints for implementation; dividing by a small `sin(theta)-v cos(theta)` near a horizon is unnecessary.

When theta + V/2 is below 90 degrees, the nearest horizontal ground lies forward. At exactly 90 degrees the nadir is a sensor boundary. Above 90 degrees the bottom image extends behind the mount's horizontal heading. This rear ground can still have **positive optical depth**. It must not be confused with ground behind the optical plane, which must be rejected even if absolute perspective ratios happen to fit the sensor.

For an image ray with normalized coordinates u,w, its world direction is A + u R + w B. If its vertical component is negative, intersect it with ground at positive t = z / (sin(theta) + w cos(theta)):

```text
X = t u
Y = t (cos(theta) - w sin(theta)).
```

If the denominator is zero the ray is parallel to ground; if negative it points upward and has no forward ground hit. This inverse projection is independently checked at 25 sensor positions per camera, excluding upward/horizon rays.

When theta > V/2 and range does not cut any corner, the footprint is a trapezoid. Its straight upper/lower boundaries are Ymin/Ymax and its half width is a(Y cos(theta)+z sin(theta)). Direct integration yields

```text
area = a cos(theta) (Ymax²-Ymin²)
     + 2 a z sin(theta) (Ymax-Ymin).
```

The oracle independently clips planar halfplanes, then computes polygon/disk intersection area by edge circle crossings and Green's theorem (triangle contributions inside and circular-sector contributions outside). It does not copy the application's ray loops or use its polygon-clipping dependency. These calculations use binary64 trigonometric coefficients; they are not an arbitrary-precision real-number proof.

## Concrete cases

All coordinates below are camera-local metres, bearing 0, with no obstacles. The frozen corpus includes rotations to 37/271 degrees and translations up to +/-1750 metres for the principal examples.

1. Ordinary camera: z=4, tilt45, HFOV90, VFOV30, range50. Current near/far are radial 2.309401/6.928203. Point (1.6,1.9) is reported visible and lies inside the drawn fan, but normalized sensor-down is 0.355932 > tan15 = 0.267949. Point (5,5) is reported blind, but normalized coordinates are (0.785674,-0.111111), comfortably within both sensor bounds and positive depth 6.363961. The ideal unobstructed area is 56.2977799203 m²; the drawn fan is 33.5043408095 m² (about 40.49% smaller in total, while still including some invalid ground).

2. Ordinary lateral distortion: z4, tilt30, HFOV90, VFOV60, range50. Point (19.8,20) is currently visible but normalized horizontal coordinate is 1.024818 > tan45 = 1. Point (5.5,5) is currently blind while normalized coordinates (0.868861,0.152304) fit the sensor. Neither point is close to an ideal or polygon boundary. Horizontal sensor FOV does not equal a constant ground azimuth interval after tilt.

3. Valid UI reversal: z20, tilt45, HFOV90, VFOV30, range250. Zone rectangle [7.7,9.1] to [8.9,10.3], area1.44 m², displays 100% currently but is entirely below the sensor's bottom boundary (true coverage0%). Route [(8,9.5),(9,9.5)] and its rehearsal midpoint are also falsely visible. Zone [25,25] to [26.2,26.2], area1.44 m², displays0% although every point is sensor-visible (true100%); its one-metre route is likewise falsely blind. These claims are source function/consumer consequences, not browser screenshots.

4. Nadir-crossing: z4, tilt75, HFOV90, VFOV60, range50. True forward bounds are -1.07179677 to4 m. Rear zone [-1,-1] to[1,-0.4], area1.2 m², and route [(-1,-0.75),(1,-0.75)] are fully visible ideally, but current metrics and rehearsal report no visibility. Point (0,-0.75) has positive optical depth3.669589 and normalized vertical0.479542 < tan30. The mount's ground projection (0,0) and side point (2,0.5) are also valid sensor ground and currently blind. Ideal area43.0356226641 m² vs drawn12.5640895310 m² (about70.81% smaller).

5. Supported extremes are retained: tilt89 with VFOV5, tilt89/HFOV170/VFOV150, tilt0, a top edge parallel to ground, empty ground intersection at short range, and circular clipping. No support is narrowed. One valid z150/tilt89/HFOV170/VFOV150/range1 configuration sees the entire unit range disk ideally; the current fan covers only1.3809703 m² vs pi m². Its square zone [-0.6,-0.6]–[0.6,0.6] is fully sensor-visible but reports about40.7562%. A separate behind-optical-plane fixture confirms that negative depth must stay invisible.

## Safe implementation direction and consumer risks

A focused correction can cover the entire currently validated tilt/FOV/range domain: construct the local range disk and clip it by the affine sensor halfplanes, then rotate/translate back. For exact metric geometry the disk has circular arcs; a polygon-returning API needs an explicit bounded arc error. Insert analytic line/circle intersections and subdivide only remaining arcs by a documented maximum sagitta or angle. Do not replace missing regions with a sample grid or discard nadir-crossing views. A finite clipping box and the disk bound all supported cases, including parallel/upward rays, without far-distance overflow.

A polygon approximation of the disk is an approximation of an ideal boundary, even when area/route integration is exact for the returned polygon. An inscribed disk polygon yields a conservative subset before arithmetic tolerance. Its maximum chord deviation is R*(1-cos(delta/2)); keep this error separate from camera calibration. The existing 48 chords over a170-degree sector at300m can deviate by about0.143m at a far-edge midpoint. More vertices raise work and must remain bounded and source-bound. No tolerance should turn a whole near-horizon region into visible ground.

Audit the shared consumers together:

- `facility.mjs:353–390`: `groundRange`, `coverageFan` and `seesPoint` share the old radial model. A point predicate can use the exact affine/disk contract. A shape producer needs full support around the mount when nadir is included. A signed forward coordinate is not a nonnegative radial distance: do not silently change `.near/.far` semantics in downstream tables.
- `facility-coverage.mjs:5–20,294–309`: `fanCache`, enabled fans and zone/route metrics reuse this geometry. Cache keys already include pose/FOV/range. Preserve distinct-camera grouping and budget behavior. Existing precise area/route receipts qualify their old drawn polygons; they do not validate a new camera model. New footprint provenance and source hashes are needed, while old evidence remains historical. The 500-camera metadata bound does not qualify rendering speed.
- `facility-map.mjs:91–109`: 3-D volume rendering assumes `fan` is `[outer rays, reversed inner rays, closure]` and takes exactly half the ring. A corrected arbitrary convex boundary will break that assumption. Triangulate from the actual boundary or retain an explicit topology object; do not feed a new ring into the old half-index code.
- `facility-map.mjs:571–576`: 2-D coverage polygon rendering can consume a single corrected simple ring. DORI overlay and labels need a coordinated geometry contract. If wall work later returns multiple components/holes, map, installer and enabled-fan adapters also need that explicit topology.
- `facility-dori.mjs`, `FacilityBuilder.jsx:1111–1118`, `facility-installer.mjs:22–26`: current main has the old slant/radial DORI model; the separate DORI projection proposal must be reconciled rather than overwritten. Correct horizontal ground density uses optical depth D; rear signed-Y intervals and distance labels require deliberate semantics. Equal-density contours are constant-Y lines, clipped to the actual sensor footprint. They are not concentric circles.
- `facility-installer.mjs:31–49`: printed fans use the same ring; ground-range text currently implies a single nonnegative radial interval. Preserve offline export, saved camera parameters and labels while correcting that meaning.
- `facility-camera-preview.mjs:6–10`, `FacilityCameraPreview.jsx:96`: displayed left/right headings are bearing +/-HFOV/2. For a tilted camera even image-midline edge azimuth is atan(tan(HFOV/2)/cos(theta)), and top/bottom edges differ. At tilt45/HFOV90, midline edge azimuth is54.7356 degrees, not45. Labels must distinguish sensor angle from ground heading; no optical calibration should be implied.
- `facility.mjs:409–422`: simulated rehearsal uses `seesPoint`; update the predicate with the footprint contract so coverage and proposed transitions are corrected together. Preserve simulated/no-identity labels, playback pace and sample bounds.
- Map fans and drag previews are computed outside the metrics worker, so bounded polygon construction and wall work still matter on the main thread. Reuse caches; do not infer performance from these small geometry probes.

### Walls remain a separate approximation

The present `clippedRay` tests wall height along a ray to a chosen ground target, then the fan shortens an entire polar ray to that wall. It only samples the height toward the current far endpoint. A low wall may hide a finite ground interval while more distant ground is visible over it; an elevated wall can permit a near view underneath. A single radial stop cannot represent those shadows. The current map fan and point predicate already use different target distances for the wall test. The mounting-clearance exemption is also a deliberate planning rule, not measured optics.

The projection examples here use no walls, so correcting them need not claim this wall model is solved. For future exact wall shadows, a target at ground distance d with a wall at distance s has height z*(1-s/d) at the wall; the blocked d interval depends on both wall base and top and can be finite. Occlusion can therefore create fragments/holes and requires explicit topology or a separately documented approximation. A new frustum must not silently reuse an incomplete constant-azimuth sweep and claim exact calibrated visibility.
