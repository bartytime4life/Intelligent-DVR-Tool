# Independent ground-frustum review

No interior or scalar blocker was found in the final candidate. This conclusion is limited to the generated, source-bound geometry and consumer checks below. The raw ideal-view gate still fails on two exact-circle boundary points by design; it has not been relabeled as a strict pass.

Final numerical source: `src/facility-visibility.mjs`, SHA256 `c2f8e13a86e1a0b4e15d92fa2e61a0585d143576dcaa48cda2c38aad6fcefb53`.

Robust geometry wrapper: `src/facility-polygon.mjs`, SHA256 `e8ac82a5ad920a1a74b98e59f971bacdd4db659da72207ebbdd175fba32ef495`. Executed snapshots bind the installed `polyclip-ts`/`bignumber.js`/`splaytree-ts` bytes. Eighty decimal places remain finite precision; these tests do not prove the absence of all Boolean-geometry failures.

## Immutable ideal-view corpus

The original 31 plans, points and expected matrix projections are unchanged. Their input SHA256 remains `b90b54b25d18a14b9400445f101c755a3f2bc7b501d15489e284a54fb764bce3`.

`candidate31-c2f8/receipt.json` retains all365 comparisons and exits1 with exactly two failures:

- `finite-range-disk`, point(3,4), on the exact radius5 circle;
- `upper-edge-horizon`, point(30,40), on the exact radius50 circle.

Both are visible in the ideal disk and excluded by the finite inscribed 256-gon. No point or expectation was filtered, rounded or rewritten to obtain this result. The separate stated approximation assessment passes for all31 shapes. All59 analytic point queries now agree with the frozen ideal matrix oracle, including the exact sensor-edge point(10,10). Its earlier binary-tangent boundary disagreement is retained in `candidate31-final/receipt.json` on source670a, and the source correction is separately bound to c2f8.

All31 validated-plan, accepted-snapshot, provenance and pure/snapshot geometry equality checks pass. All10 zone fractions,10 route fractions and10 rehearsal midpoint results match the unchanged ideal expectations. This confirms that the source-valid 100%↔0% counterexamples have been corrected in the current consumer functions; no browser or physical-camera result is claimed here.

## Independent wall extension

`wall-extension/inputs.json` contains42 independently selected scenes and38,196 point queries. SHA256 `4ba8fad33036f05c3c6478eb6e67cb809507a1b9b352db4c47bd6f6192bfa897`.

`wall-extension/expected.json` SHA256 `68da28a306c623041dd18335bd905f161f9ca0ece185528a51a42e44466ea98f`.

The expected values were frozen before executing the candidate. Eleven scenes additionally construct validated facility building plans. Short/open/thin-face fixtures are explicitly labeled supported pure wall-face inputs and are not promoted into valid standalone building footprints. The extension includes low finite shadows, raised-wall under/over recovery, one/two blind holes, disconnected visible components, a camera enclosed by walls, rear/nadir shadows, diagonal and overlapping walls, facade policy limits, seeded scenes and full-range disk views.

Two independent calculations crosscheck the reference:

1. Fraction arithmetic intersects a 3-D camera-to-ground segment with a vertical face plane, then tests its independent horizontal/vertical face coordinates.
2. Independently projected 3-D face corner boundaries and the independently generated range256-gon form a rational planar arrangement. All vertex/intersection ordinates partition the plane into slabs. Interval endpoints are affine inside a slab, so rational midpoint integration gives exact area for those supplied boundaries. Output XOR covers every returned component and hole, including any misplaced area outside the expected footprint.

The reference's own ray-versus-projected-mask checks pass. Three oracle-determined face/height/coplanarity boundary queries were excluded before any candidate execution; no candidate boundary was used to hide a mismatch. Exact closed-face ray LOS can differ from a closed regularized polygon at isolated shadow boundaries, which have zero area. The chord-band eligibility rule is also fixed geometrically; no extension queries happen to fall in that band.

Strict baseline on git96b37413abcf2ebe7692f4fa6bdb6338bf2fb70a exits1 with12,634 failed comparisons. Strict final c2f8 candidate exits0 with **76,717 assertions, zero failures**, including:

- 38,193 eligible exact point-LOS checks;
- 38,193 polygon-point checks;
- 42 rational visible-area comparisons;
- 42 full-output rational XOR comparisons;
- 26 explicit component/hole topology checks;
- method, success, range-chord metadata and valid-plan checks.

Maximum observed area error:2.6574298317427747e-12m². Maximum observed XOR area:7.561086573208324e-12m². These are corpus observations, not universal error bounds. The predeclared scalar/XOR tolerance is2e-8m² and is unchanged after candidate execution.

Selected topology receipts include a low-wall blind hole, a raised finite blind hole, two separate blind holes and two visible components divided by a full-width raised-wall shadow. Valid-building low/raised-hole fixtures also pass. Distinct-camera identity is tested separately below.

The earlier4869 and670a candidate receipts are retained. Updating the snapshot file list to include the newly imported protocol module changed packaging only; baseline and candidate were both rerun under the same final checker. Fixture preparation, including the pre-candidate diagonal-shadow topology correction and direct-wall-face classification, remains in `wall-extension/preparation-40`; no candidate result was used to modify an expected outcome.

## Production consumer checks

`wall-extension/metrics-c2f8/receipt.json`: **39,075 assertions, zero failures** across the unchanged42 cases.

For each scene this uses two different camera IDs with identical poses, checks the pose cache, and sends the accepted MultiPolygon snapshots into the actual current `coverageMetrics` and `visibleAtPoint` functions. Independently generated vertical-route interval expectations exercise holes and disconnected components. It verifies:

- exact zone covered/overlap areas and fractions for two distinct camera IDs;
- route covered/overlap lengths, fractions and longest continuous blind stretch;
- 38,193 snapshot point results against the frozen 3-D LOS oracle;
- original-plan provenance, rejected different-plan identity, clone initially unbound and explicit clone reacceptance;
- resource-refused visibility staying unavailable: point/rehearsal null, zone numerics and blind geometry null, route numerics null.

Metrics expectations were written before executing the application consumers. Consumer scalar tolerance is2e-8 in the displayed units. This is not a test of browser worker deadlines, drawing performance, hardware throughput, optical quality or physical wall geometry.

## Reproduction

Run from the source checkout into fresh output directories. The scripts copy and hash public source/dependency bytes before executing Node; no application files are modified.

```sh
python3 /tmp/dvr-frustum-study-20261112/check-candidate31.py --repo . --out /tmp/dvr-frustum-study-20261112/replay31-new --require-pass
python3 /tmp/dvr-frustum-study-20261112/wall-extension/check-wall.py --repo . --mode baseline --out /tmp/dvr-frustum-study-20261112/wall-extension/replay-baseline-new --require-pass
python3 /tmp/dvr-frustum-study-20261112/wall-extension/check-wall.py --repo . --mode candidate --out /tmp/dvr-frustum-study-20261112/wall-extension/replay-candidate-new --require-pass
python3 /tmp/dvr-frustum-study-20261112/wall-extension/check-metrics.py --repo . --source-snapshot /tmp/dvr-frustum-study-20261112/wall-extension/replay-candidate-new/snapshot --out /tmp/dvr-frustum-study-20261112/wall-extension/replay-metrics-new --require-pass
```

Expected exit codes against the recorded final source:1(raw ideal circle boundaries),1(legacy baseline),0(wall candidate),0(consumers). Replaying a later source revision produces new source bindings and must not be described as the recorded source result automatically.

The derivation, original counterexamples and consumer migration risks are in `findings.md`. Primary camera-model basis: [official OpenCV projection documentation](https://docs.opencv.org/4.13.0/d9/d0c/group__calib3d.html). All findings describe an ideal centred rectilinear sensor on flat ground, modeled opaque vertical faces and the explicit mounting-clearance policy. They do not establish lens calibration, optical sharpness, physical visibility, recognition accuracy, real cameras, installation, capacity or novice-user acceptance.
